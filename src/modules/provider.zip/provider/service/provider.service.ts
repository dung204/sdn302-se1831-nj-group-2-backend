import { SortOrder } from 'mongoose';

import { CreateProviderDto, ProviderQueryDto } from '../dtos';
import { ProviderModel } from '../models';

class ProviderService {
  findAllAndCount({ page, pageSize, sorting }: ProviderQueryDto) {
    const query = ProviderModel.find()
      .limit(pageSize)
      .skip((page - 1) * pageSize)
      .sort(
        sorting.map(
          ({ field, direction }) => [field, direction] as [string, SortOrder],
        ),
      );

    return query.exec();
  }

  findAllDeleted() {}

  findOneById() {}

  createProvider(createProviderDto: CreateProviderDto) {
    const provider = new ProviderModel(createProviderDto);
    return provider.save();
  }

  updateProvider() {}

  softDeleteProvider() {}

  restoreProvider() {}
}

export const providerService = new ProviderService();
