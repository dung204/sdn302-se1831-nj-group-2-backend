// import { NextFunction, Request , Response  } from "express"
// import { providerService } from "../service/provider.service"
// import {createProviderDto} from "../dtos/create-provider.dto"
// import { providerQueryDto } from "../dtos"

// class ProviderController {

//     /**
//      * [GET] /api/v1/provider
//      */
//     // async findAll(req:Request,res:Response,next:NextFunction){
//     //     const dto = providerQueryDto.parse(req.query)
//     //     res.json(await providerService.findAllAndCount(dto))
//     // }

//     // /**
//     //  * [GET] /api/v1/provider/deleted
//     //  */
//     // findAllDeleted(req:Request,res:Response,next:NextFunction){

//     // }

//     // /**
//     //  * [GET] /api/v1/provider/:id
//     //  */
//     // findOneById(req:Request,res:Response,next:NextFunction){

//     // }

//     /**
//      * [POST] /api/v1/provider
//      */
//     // async createProvider(req:Request,res:Response,next:NextFunction){
//     //     const dto = createProviderDto.parse(req.body)
//     //     res.json(await providerService.createProvider(dto))
//     // }

//     // /**
//     //  * [PATCH] /api/v1/provider/:id
//     //  */
//     // updateProvider(req:Request,res:Response,next:NextFunction){
//     // }

//     // /**
//     //  * [DELETE] /api/v1/provider/:id
//     //  */
//     // softDeleteProvider(req:Request,res:Response,next:NextFunction){

//     // }

//     // /**
//     //  * [PATCH] /api/v1/provider/users/:id
//     //  */
//     // restoreProvider(req:Request,res:Response,next:NextFunction){

//     // }

// }

// export const providerController = new ProviderController()
